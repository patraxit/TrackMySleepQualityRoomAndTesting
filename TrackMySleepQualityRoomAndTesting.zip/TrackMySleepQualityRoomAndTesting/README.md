
Introduction
------------

TrackMySleepQuality is an app for recording sleep data for each night. 
You can record a start and stop time, assign a quality rating, and clear the database. 

This version of the app contains the Room database that holds the sleep data 
and instrumented tests to verify that this backend works. 
